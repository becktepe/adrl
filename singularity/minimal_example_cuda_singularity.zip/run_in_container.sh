. /opt/conda/etc/profile.d/conda.sh
conda activate cuda_test_env

python example.py
